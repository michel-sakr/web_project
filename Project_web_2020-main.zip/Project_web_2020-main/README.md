# Project_web_2020
  Web Programming Final Project - Fall 2020
  
  This website is an interactive trivia game where users can test their knowledge, chat with other users, see how much they mastered each category of the game and reach the rank of “Legendary”.
  The user will have 10 questions with several levels of difficulty and 3 skips that count as a correct answer. Some are multiple choice questions, others true or false. 
  A leaderboard where all the users are ranked according to a specific category or simply a global ranking.
  Discord servers to chat with other users are also included on the website.
